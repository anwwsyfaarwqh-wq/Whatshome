const BASE_HEADERS = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "X-Frame-Options": "DENY",
  "Permissions-Policy": "geolocation=(), camera=(), microphone=()"
};
const enc = new TextEncoder();
function headers(request) {
  const h = new Headers(BASE_HEADERS);
  const origin = request.headers.get("Origin");
  const requestOrigin = new URL(request.url).origin;
  // API accepts only same-origin browser calls; command-line clients without Origin remain possible.
  if (!origin || origin === requestOrigin) {
    h.set("Access-Control-Allow-Origin", requestOrigin);
    h.set("Vary", "Origin");
  }
  h.set("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  h.set("Access-Control-Allow-Headers", "Content-Type,Authorization");
  return h;
}
function json(request, data, status=200) {
  return new Response(JSON.stringify(data), {status, headers:headers(request)});
}
function b64(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))); }
function unb64(s) { return Uint8Array.from(atob(s), c=>c.charCodeAt(0)); }
async function sha256(s) {
  const d = await crypto.subtle.digest("SHA-256", enc.encode(s));
  return [...new Uint8Array(d)].map(x=>x.toString(16).padStart(2,"0")).join("");
}
async function passwordHash(password, salt) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({name:"PBKDF2", salt:unb64(salt), iterations:310000, hash:"SHA-256"}, key, 256);
  return b64(bits);
}
function randomId() { return crypto.randomUUID(); }
function cleanUser(u) { return {id:u.id, username:u.username, displayName:u.display_name, createdAt:u.created_at}; }
async function parseBody(request) {
  const len=Number(request.headers.get("Content-Length")||0);
  if(len>12000) throw new Error("حجم الطلب كبير جدًا.");
  return await request.json();
}
async function rateLimit(request, env, action, maxHits, windowMs) {
  const ip=request.headers.get("CF-Connecting-IP")||"unknown";
  const key=await sha256(action+":"+ip);
  const now=Date.now(), start=Math.floor(now/windowMs)*windowMs;
  const row=await env.DB.prepare("SELECT window_start,hits FROM rate_limits WHERE bucket_key=?").bind(key).first();
  if(!row || row.window_start!==start) {
    await env.DB.prepare("INSERT INTO rate_limits(bucket_key,window_start,hits) VALUES(?,?,1) ON CONFLICT(bucket_key) DO UPDATE SET window_start=excluded.window_start,hits=1").bind(key,start).run();
    return false;
  }
  if(row.hits>=maxHits) return true;
  await env.DB.prepare("UPDATE rate_limits SET hits=hits+1 WHERE bucket_key=?").bind(key).run();
  return false;
}
async function currentUser(request, env) {
  const h=request.headers.get("Authorization")||"";
  const token=h.startsWith("Bearer ")?h.slice(7):"";
  if (!token || token.length>200) return null;
  const row=await env.DB.prepare(`SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?`).bind(await sha256(token), Date.now()).first();
  if(row) await env.DB.prepare("UPDATE users SET last_seen=? WHERE id=?").bind(new Date().toISOString(),row.id).run();
  return row||null;
}
async function issueSession(user, env) {
  const token=b64(crypto.getRandomValues(new Uint8Array(32)));
  await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)")
    .bind(await sha256(token), user.id, Date.now()+30*24*60*60*1000).run();
  return token;
}
async function handle(request, env) {
  const url=new URL(request.url), path=url.pathname;
  if(request.method==="OPTIONS") return new Response(null,{status:204,headers:headers(request)});
  if (path.startsWith("/api/")) {
    if (!env.DB) return json(request,{error:"قاعدة البيانات غير مربوطة. أنشئ D1 واربطها باسم DB ثم طبّق schema.sql."},503);
    try {
      if (request.method==="POST" && (path==="/api/register" || path==="/api/login")) {
        const action=path.endsWith("register")?"register":"login";
        if(await rateLimit(request,env,action,action==="register"?5:12,15*60*1000))
          return json(request,{error:"محاولات كثيرة خلال وقت قصير. انتظر 15 دقيقة ثم حاول مجددًا."},429);
        const body=await parseBody(request);
        if(action==="register") {
          const un=String(body.username||"").trim().toLowerCase();
          const dn=String(body.displayName||"").trim();
          const password=body.password;
          if (!/^[a-z0-9_]{3,24}$/.test(un)) return json(request,{error:"اسم المستخدم يجب أن يكون 3 إلى 24 حرفًا إنجليزيًا أو رقمًا أو _."},400);
          if (dn.length<2||dn.length>50) return json(request,{error:"اكتب اسمًا من حرفين إلى 50 حرفًا."},400);
          if (typeof password!=="string"||password.length<10||password.length>128) return json(request,{error:"كلمة المرور يجب أن تكون من 10 أحرف على الأقل."},400);
          const salt=b64(crypto.getRandomValues(new Uint8Array(16)));
          const hash=await passwordHash(password,salt), id=randomId();
          try {
            await env.DB.prepare("INSERT INTO users(id,username,display_name,password_salt,password_hash) VALUES(?,?,?,?,?)").bind(id,un,dn,salt,hash).run();
          } catch { return json(request,{error:"اسم المستخدم مستخدم بالفعل أو تعذّر إنشاء الحساب."},409); }
          const user=await env.DB.prepare("SELECT * FROM users WHERE id=?").bind(id).first();
          return json(request,{user:cleanUser(user),token:await issueSession(user,env)},201);
        }
        const username=String(body.username||"").trim().toLowerCase(), password=String(body.password||"");
        if(username.length>24||password.length>128) return json(request,{error:"بيانات الدخول غير صحيحة."},400);
        const user=await env.DB.prepare("SELECT * FROM users WHERE username=?").bind(username).first();
        const valid=user ? await passwordHash(password,user.password_salt).then(h=>h===user.password_hash) : false;
        if (!valid) return json(request,{error:"اسم المستخدم أو كلمة المرور غير صحيحة."},401);
        await env.DB.prepare("UPDATE users SET last_seen=? WHERE id=?").bind(new Date().toISOString(),user.id).run();
        return json(request,{user:cleanUser(user),token:await issueSession(user,env)});
      }
      const me=await currentUser(request,env);
      if (!me) return json(request,{error:"انتهت الجلسة أو لم تسجّل الدخول. سجّل الدخول مجددًا."},401);
      if (request.method==="POST" && path==="/api/logout") {
        const token=(request.headers.get("Authorization")||"").slice(7);
        await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await sha256(token)).run();
        return json(request,{ok:true});
      }
      if (request.method==="GET" && path==="/api/me") return json(request,{user:cleanUser(me)});
      if (request.method==="GET" && path==="/api/users") {
        const q=(url.searchParams.get("q")||"").trim().toLowerCase();
        if(q.length<2||q.length>24) return json(request,{users:[]});
        const rows=await env.DB.prepare("SELECT id,username,display_name FROM users WHERE username LIKE ? AND id<>? LIMIT 20").bind("%"+q.replace(/[%_]/g,"")+"%",me.id).all();
        return json(request,{users:rows.results.map(cleanUser)});
      }
      if (request.method==="POST" && path==="/api/conversations") {
        const {userId}=await parseBody(request);
        if(!userId||userId===me.id) return json(request,{error:"اختر مستخدمًا آخر."},400);
        const other=await env.DB.prepare("SELECT id FROM users WHERE id=?").bind(userId).first();
        if(!other) return json(request,{error:"المستخدم غير موجود."},404);
        const [a,b]=[me.id,userId].sort();
        await env.DB.prepare("INSERT OR IGNORE INTO conversations(id,user_a,user_b) VALUES(?,?,?)").bind(randomId(),a,b).run();
        const c=await env.DB.prepare("SELECT * FROM conversations WHERE user_a=? AND user_b=?").bind(a,b).first();
        return json(request,{conversation:c.id});
      }
      if (request.method==="GET" && path==="/api/conversations") {
        const rows=await env.DB.prepare(`SELECT c.id,c.created_at,
          CASE WHEN c.user_a=? THEN u2.id ELSE u1.id END AS peer_id,
          CASE WHEN c.user_a=? THEN u2.username ELSE u1.username END AS peer_username,
          CASE WHEN c.user_a=? THEN u2.display_name ELSE u1.display_name END AS peer_name,
          (SELECT body FROM messages m WHERE m.conversation_id=c.id ORDER BY created_at DESC LIMIT 1) AS last_message
          FROM conversations c JOIN users u1 ON u1.id=c.user_a JOIN users u2 ON u2.id=c.user_b
          WHERE c.user_a=? OR c.user_b=? ORDER BY c.created_at DESC LIMIT 100`).bind(me.id,me.id,me.id,me.id,me.id).all();
        return json(request,{conversations:rows.results});
      }
      const msgMatch=path.match(/^\/api\/conversations\/([a-f0-9-]+)\/messages$/i);
      if(msgMatch) {
        const cid=msgMatch[1];
        const c=await env.DB.prepare("SELECT id FROM conversations WHERE id=? AND (user_a=? OR user_b=?)").bind(cid,me.id,me.id).first();
        if(!c) return json(request,{error:"لا تملك صلاحية الوصول إلى هذه المحادثة."},403);
        if(request.method==="GET") {
          const rows=await env.DB.prepare("SELECT id,sender_id,body,created_at FROM messages WHERE conversation_id=? ORDER BY created_at DESC LIMIT 100").bind(cid).all();
          return json(request,{messages:rows.results.reverse()});
        }
        if(request.method==="POST") {
          if(await rateLimit(request,env,"messages:"+me.id,60,60*1000)) return json(request,{error:"أرسلت رسائل كثيرة بسرعة. انتظر قليلًا."},429);
          const {body}=await parseBody(request), text=String(body||"").trim();
          if(!text||text.length>4000) return json(request,{error:"الرسالة فارغة أو أطول من 4000 حرف."},400);
          const id=randomId();
          await env.DB.prepare("INSERT INTO messages(id,conversation_id,sender_id,body) VALUES(?,?,?,?)").bind(id,cid,me.id,text).run();
          const m=await env.DB.prepare("SELECT id,sender_id,body,created_at FROM messages WHERE id=?").bind(id).first();
          return json(request,{message:m},201);
        }
      }
      return json(request,{error:"المسار غير موجود."},404);
    } catch(e) {
      return json(request,{error:e.message==="حجم الطلب كبير جدًا."?e.message:"حدث خطأ في الخادم. تأكد من تطبيق schema.sql وربط D1 ثم أعد المحاولة."},500);
    }
  }
  if(env.ASSETS) {
    const response=await env.ASSETS.fetch(request);
    const h=new Headers(response.headers);
    h.set("X-Content-Type-Options","nosniff"); h.set("Referrer-Policy","strict-origin-when-cross-origin"); h.set("X-Frame-Options","DENY");
    return new Response(response.body,{status:response.status,statusText:response.statusText,headers:h});
  }
  return new Response("WhatsBit — يرجى ربط الأصول الثابتة.",{status:200,headers:headers(request)});
}
export default {fetch:handle};
